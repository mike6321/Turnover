package com.example.joguk.geoquizguk.library;

public enum IndicatorType {
    LINE, CIRCLE
}
