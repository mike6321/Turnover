package com.example.joguk.criminalintent;

public abstract class SwipeControllerActions {
    public void onLeftClicked(int position) {}
    public void onRightClicked(int position) {}
}